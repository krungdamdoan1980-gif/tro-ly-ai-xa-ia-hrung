import React from "react";
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from "react-native";
import { MaterialIcons, Entypo, FontAwesome5, Feather, Ionicons } from "@expo/vector-icons";

export default function App() {
  const features = [
    { label: "Lịch công tác", icon: <MaterialIcons name="event" size={36} color="#b00000" /> },
    { label: "Văn bản – Chỉ đạo", icon: <Entypo name="text-document" size={36} color="#b00000" /> },
    { label: "Dịch vụ công", icon: <Entypo name="briefcase" size={36} color="#b00000" /> },
    { label: "Tham gia ý kiến", icon: <FontAwesome5 name="users" size={32} color="#b00000" /> },
    { label: "Phân tích dữ liệu", icon: <Entypo name="bar-graph" size={36} color="#b00000" /> },
    { label: "Nhắc lịch", icon: <MaterialIcons name="notifications-active" size={36} color="#b00000" /> },
    { label: "Chuyển đổi số – Đề án 06", icon: <Ionicons name="cloud-outline" size={36} color="#b00000" /> },
    { label: "Xử lý vi phạm", icon: <Ionicons name="shield-checkmark-outline" size={36} color="#b00000" /> }
  ];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Trợ lý AI – Chủ tịch UBND xã Ia Hrung</Text>
      <View style={styles.grid}>
        {features.map((f, i) => (
          <TouchableOpacity key={i} style={styles.card}>
            {f.icon}
            <Text style={styles.label}>{f.label}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <Text style={styles.footer}>Thiết kế bởi Trợ lý Krung</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fdfbf8", padding: 16 },
  header: { fontSize: 18, fontWeight: "bold", textAlign: "center", color: "#b00000", marginBottom: 12 },
  grid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-around" },
  card: {
    width: "40%",
    backgroundColor: "#fff",
    borderWidth: 2,
    borderColor: "#b00000",
    borderRadius: 12,
    alignItems: "center",
    padding: 12,
    marginBottom: 16
  },
  label: { marginTop: 8, textAlign: "center", fontWeight: "600" },
  footer: { textAlign: "center", fontSize: 12, marginTop: 24, color: "#777" }
});