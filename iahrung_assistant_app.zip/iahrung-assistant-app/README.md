# Trợ lý AI - Chủ tịch UBND xã Ia Hrung (Expo App)

## Cách sử dụng:

1. Cài Expo CLI:
   npm install -g expo-cli

2. Cài dependencies:
   npm install

3. Chạy thử app:
   npm start